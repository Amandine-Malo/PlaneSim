#include "pilote.h"
#include "ui_pilote.h"

Pilote::Pilote(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Pilote)
{
    ui->setupUi(this);
}

Pilote::~Pilote()
{
    delete ui;
}

void Pilote::setCockpit(MainWindow *p)
{
    cockpit = p;
}

void Pilote::on_VT12_clicked()
{
    cockpit->VT12();
}

void Pilote::on_VT23_clicked()
{
    cockpit->VT23();
}

void Pilote::on_P12_clicked()
{
    cockpit->ManagePump(0,1);
}

void Pilote::on_P22_clicked()
{
    cockpit->ManagePump(1,1);
}

void Pilote::on_P32_clicked()
{
    cockpit->ManagePump(2,1);

}

void Pilote::on_V12_clicked()
{
    cockpit->ManageVannes(0);
}

void Pilote::on_V13_clicked()
{
    cockpit->ManageVannes(1);
}

void Pilote::on_V23_clicked()
{
    cockpit->ManageVannes(2);
}

void Pilote::closeEvent(QCloseEvent *event)
{
    QApplication::quit();
}
