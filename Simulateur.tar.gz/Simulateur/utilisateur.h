#ifndef UTILISATEUR_H
#define UTILISATEUR_H

#include <QMainWindow>
#include "mainwindow.h"

namespace Ui {
class Utilisateur;
}

class Utilisateur : public QMainWindow
{
    Q_OBJECT

public:
    explicit Utilisateur(QWidget *parent = nullptr);
    ~Utilisateur();
    void setCockpit(MainWindow *p);
    void nextAlea();

private slots:
    void on_PANNE_13_clicked();
    void on_PANNE_14_clicked();
    void on_PANNE_17_clicked();
    void on_PANNE_18_clicked();
    void on_PANNE_21_clicked();
    void on_PANNE_22_clicked();
    void on_VIDANGE_4_clicked();
    void on_VIDANGE_5_clicked();
    void on_VIDANGE_6_clicked();

private:
    Ui::Utilisateur *ui;
    MainWindow *cockpit;
    void closeEvent(QCloseEvent* event);
};

#endif // UTILISATEUR_H
