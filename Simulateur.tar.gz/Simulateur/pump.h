#ifndef PUMP_H
#define PUMP_H


class Pump
{
private:
    int status;

public:
    Pump();
    ~Pump();
    void StartPump();
    void StopPump();
    void ErrorPump();
    int GetStatus();
};

#endif // PUMP_H
