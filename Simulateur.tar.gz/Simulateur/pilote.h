#ifndef PILOTE_H
#define PILOTE_H

#include <QMainWindow>
#include "mainwindow.h"

namespace Ui {
class Pilote;
}

class Pilote : public QMainWindow
{
    Q_OBJECT

public:
    explicit Pilote(QWidget *parent = nullptr);
    ~Pilote();
    void setCockpit(MainWindow *p);

private slots:
    void on_VT12_clicked();
    void on_VT23_clicked();
    void on_P12_clicked();
    void on_P22_clicked();
    void on_P32_clicked();
    void on_V12_clicked();
    void on_V13_clicked();
    void on_V23_clicked();

private:
    Ui::Pilote *ui;
    MainWindow *cockpit;
    void closeEvent(QCloseEvent* event);
};

#endif // PILOTE_H
