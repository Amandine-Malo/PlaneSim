#ifndef PILOTE_H
#define PILOTE_H

#include <QMainWindow>
#include "mainwindow.h"
#include "utilisateur.h"

namespace Ui {
class Pilote;
}

class Pilote : public QMainWindow
{
    Q_OBJECT

public:
    explicit Pilote(QWidget *parent = nullptr);
    ~Pilote();
    void setCockpit(MainWindow *p);
    void setUtilisateur(Utilisateur *p);

private slots:
    void on_VT12_clicked();
    void on_VT23_clicked();
    void on_P12_clicked();
    void on_P22_clicked();
    void on_P32_clicked();
    void on_V12_clicked();
    void on_V13_clicked();
    void on_V23_clicked();
    void on_Pannealea_stateChanged(int arg1);

private:
    Ui::Pilote *ui;
    MainWindow *cockpit;
    Utilisateur *u;
    int alea;
    void closeEvent(QCloseEvent* event);
};

#endif // PILOTE_H
