#include "log.h"
#include "ui_log.h"

#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>

Log::Log(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Log)
{
    ui->setupUi(this);
}

Log::~Log()
{
    delete ui;
}

void Log::addLog(const char *s)
{
    ui->Enregistreur->appendPlainText(s);
}

void Log::on_Save_clicked()
{
    QString nomFichier = QFileDialog::getSaveFileName(this, tr("Sauvegarder la simulation"), "", tr("Fichier Texte (*.txt)"));

    if (nomFichier != "") {

        QFile file(nomFichier);

        if (file.open(QIODevice::ReadWrite)) {

            QTextStream stream(&file);
            stream << ui->Enregistreur->toPlainText();
            file.flush();
            file.close();

        } else {
            QMessageBox::critical(this, tr("Erreur"), tr("Impossible de sauvegarder la simulation"));
            return;
        }
    }
}
