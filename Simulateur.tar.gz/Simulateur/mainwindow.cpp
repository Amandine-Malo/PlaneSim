﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QInputDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QDate>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    Engine[0] = new Motor(0);
    Engine[1] = new Motor(1);
    Engine[2] = new Motor(2);

    VT[0] = new Vanne();
    VT[1] = new Vanne();

    Vn[0] = new Vanne();
    Vn[1] = new Vanne();
    Vn[2] = new Vanne();

    pTank[0] = new Tank();
    pTank[1] = new Tank();
    pTank[2] = new Tank();

    bool ok;
    QString item = QInputDialog::getText(this, tr("Pilote"), tr("Pilote"), QLineEdit::Normal, "", &ok);

    if (ok && !item.isEmpty())
        aviator = item;
    else {
        aviator = tr("QUIT");
        return;
    }

    ui->setupUi(this);

    refreshScreen();
}

MainWindow::~MainWindow()
{
    delete Engine[0]; delete Engine[1]; delete Engine[2];
    delete VT[0]; delete VT[1];
    delete Vn[0]; delete Vn[1]; delete Vn[2];
    delete pTank[0]; delete pTank[1]; delete pTank[2];
    delete ui;
}

//
// Partie Pilote
//

// Gestion essence M1 M2    Utilisateur u;
void MainWindow::VT12()
{
    if(ui->VT12_2->value() == 0 ) {
        addLog(tr("Activation VT12"));
        ui->VT12_2->setValue(1);

        // Si reservoir 1 vide
        if( pTank[0]->GetTankStatus() == 0 ) {
            ui->T1T2->setStyleSheet(C_TANK2);
            pTank[0]->FillTank();
            Engine[0]->setiTank(0);
        }

        // Si reservoir 2 vide
        if( pTank[1]->GetTankStatus() == 0 ) {
            ui->T1T2->setStyleSheet(C_TANK1);
            pTank[1]->FillTank();
            Engine[1]->setiTank(1);
        }

     } else {
        addLog(tr("Désactivation VT12"));
        ui->VT12_2->setValue(0);
        ui->T1T2->setStyleSheet(C_NOCOLOR);
    }

    refreshScreen();
}

// Gestion essence M2 M3
void MainWindow::VT23()
{
    if(ui->VT23_2->value() == 0 ) {
        addLog(tr("Activation VT23"));
        ui->VT23_2->setValue(1);

        // Si reservoir 2 vide
        if( pTank[1]->GetTankStatus() == 0 ) {
            ui->T2T3->setStyleSheet(C_TANK3);
            pTank[1]->FillTank();
            Engine[1]->setiTank(1);
        }

        // Si reservoir 3 vide
        if( pTank[2]->GetTankStatus() == 0 ) {
            ui->T2T3->setStyleSheet(C_TANK2);
            pTank[2]->FillTank();
            Engine[2]->setiTank(2);
        }
     } else {
        addLog(tr("Désactivation VT23"));
        ui->VT23_2->setValue(0);
        ui->T2T3->setStyleSheet(C_NOCOLOR);
    }

    refreshScreen();
}

// Gestion pompe de secours
void MainWindow::ManagePump(int tank, int pump)
{
    int pstatus = pTank[tank]->GetPumpStatus(pump);
    QString str;

    switch(pstatus) {
        case 1:
            str = tr("Desactivation réservoir %1 pompe %2")
                    .arg(tank+1, 0, 10)
                    .arg(pump+1, 0, 10);
            addLog(str);
            pTank[tank]->SetPumpStatus(pump,0);
            break;

        case 0:
            str = tr("Activation réservoir %1 pompe %2")
                .arg(tank+1, 0, 10)
                .arg(pump+1, 0, 10);
            addLog(str);
            pTank[tank]->SetPumpStatus(pump,1);
            break;

        case -1:
            break;
    }

    // Si plus de pompes ne fonctionne sur le reservoir
    if ((pTank[tank]->GetPumpStatus(0) != 1) && (pTank[tank]->GetPumpStatus(1) != 1)) {
        if(Engine[0]->getiTank() == tank) Engine[0]->setiTank(-1);
        if(Engine[1]->getiTank() == tank) Engine[0]->setiTank(-1);
        if(Engine[2]->getiTank() == tank) Engine[2]->setiTank(-1);
    }

    // Si juste 1 pompe seulement le moteur pour la pompe
    if(((pTank[tank]->GetPumpStatus(0) != 1) && (pTank[tank]->GetPumpStatus(1) == 1)) ||
       ((pTank[tank]->GetPumpStatus(0) == 1) && (pTank[tank]->GetPumpStatus(1) != 1)))
    {
        for( int i=0 ; i<3 ; i++ ){
            if( i != tank ) {
                if( Engine[i]->getiTank() == tank )
                    Engine[i]->setiTank(-1);
            } else
                Engine[i]->setiTank(tank);
        }
    }

    refreshScreen();
}

// Gestion des Vannes
void MainWindow::ManageVannes(int vanne) {

    int m1, m2, m3, v;
    QString str;

    switch(vanne) {
        case 0:
            m1 = 0; m2 = 1; m3 = 2;
            v = 12;
            break;

        case 1:
            m1 = 0; m2 = 2; m3 = 1;
            v = 13;
            break;

        case 2:
            m1 = 1; m2 = 2; m3 = 0;
            v = 23;
            break;
    }

    // Si fermée on ouvre
    if( Vn[vanne]->getStatus() == 0) {

        // Si R 1 vide ou Pompe en erreur
        if((pTank[m1]->GetTankStatus() == 0 ) || ((pTank[m1]->GetPumpStatus(0) != 1) && (pTank[m1]->GetPumpStatus(1) != 1))) {
            // c'est 2 vers 1 mais il faut les 2 pompes en route
            if((pTank[m2]->GetPumpStatus(0) == 1) && (pTank[m2]->GetPumpStatus(1) == 1))
                // Si aucune autre moteur n'est sur le reservoir
                if(Engine[m3]->getiTank() != m2) {
                    Engine[m1]->setiTank(m2);
                    str = tr("Activation vanne %1")
                        .arg(v, 0, 10);
                    addLog(str);
                    Vn[vanne]->OpenVanne();
                 }
        }

        // Si R 2 vide ou Pompe en erreur
        if((pTank[m2]->GetTankStatus() == 0 ) || ((pTank[m2]->GetPumpStatus(0) != 1) && (pTank[m2]->GetPumpStatus(1) != 1))) {
            // c'est 2 vers 1 mais il faut les 2 pompes en route
            if((pTank[m1]->GetPumpStatus(0) == 1) && (pTank[m1]->GetPumpStatus(1) == 1))
                // Si aucune autre moteur n'est sur le reservoir
                if(Engine[m3]->getiTank() != m1) {
                    Engine[m2]->setiTank(m1);
                    str = tr("Activation vanne %1")
                        .arg(v, 0, 10);
                    addLog(str);
                    Vn[vanne]->OpenVanne();
                }
        }

    } else {

        str = tr("Desactivation vanne %1")
            .arg(v, 0, 10);
        addLog(str);
        Vn[vanne]->CloseVanne();

        // Si R 1 vide ou Pompe en erreur
        if((pTank[m1]->GetTankStatus() == 0 ) || ((pTank[m1]->GetPumpStatus(0) != 1) && (pTank[m1]->GetPumpStatus(1) != 1))) {
            if(Engine[m1]->getiTank() == m2)
                Engine[m1]->setiTank(-1);
        }

        // Si R 2 vide ou Pompe en erreur
        if((pTank[m2]->GetTankStatus() == 0 ) || ((pTank[m2]->GetPumpStatus(0) != 1) && (pTank[m2]->GetPumpStatus(1) != 1))) {
            if(Engine[m2]->getiTank() == m1)
                Engine[m2]->setiTank(-1);
        }
    }

    refreshScreen();

}

//
// Partie Utilisateur
//

// Purge réservoir
void MainWindow::Vidange(int tank)
{
    QString str;

    pTank[tank]->EmptyTank();

    if( Engine[0]->getiTank() == tank ) Engine[0]->setiTank(-1);
    if( Engine[1]->getiTank() == tank ) Engine[1]->setiTank(-1);
    if( Engine[2]->getiTank() == tank ) Engine[2]->setiTank(-1);

    switch(tank) {
        case 0:
            ui->V13_2->setValue(0);
            ui->V12_2->setValue(0);
            break;

        case 1:
            ui->V12_2->setValue(0);
            ui->V23_2->setValue(0);
            break;

        case 2:
            ui->V13_2->setValue(0);
            ui->V23_2->setValue(0);
            break;
    }

    str = tr("Vidange réservoir %1")
        .arg(tank+1, 0, 10);
    addLog(str);

    refreshScreen();

}

// Panne pompe n sur reservoir n
void MainWindow::ErrorPump(int tank, int pump)
{
    QString str;

    pTank[tank]->SetPumpStatus(pump,-1);

    // Modification interface décoché + rouge
    switch(tank){
        case 0:
            if(pump == 0) {
                ui->T1_P11->setChecked(false);
                ui->T1_P11->setStyleSheet(C_ERROR);
            }
            if(pump == 1) {
                ui->T1_P12->setChecked(false);
                ui->T1_P12->setStyleSheet(C_ERROR);
            }
            break;

        case 1:
            if(pump == 0) {
                ui->T2_P11->setChecked(false);
                ui->T2_P11->setStyleSheet(C_ERROR);
            }
            if(pump == 1) {
                ui->T2_P12->setChecked(false);
                ui->T2_P12->setStyleSheet(C_ERROR);
            }
            break;

        case 2:
            if(pump == 0) {
                ui->T3_P11->setChecked(false);
                ui->T3_P11->setStyleSheet(C_ERROR);
            }
            if(pump == 1) {
                ui->T3_P12->setChecked(false);
                ui->T3_P12->setStyleSheet(C_ERROR);
            }
            break;
    }

    // Si la 2nde pompe ne fonctionne pas - erreur moteurs
    if( pTank[tank]->GetPumpStatus((pump == 0) ? 1 : 0) != 1 ) {
        if(Engine[0]->getiTank() == tank) Engine[0]->setiTank(-1);
        if(Engine[1]->getiTank() == tank) Engine[1]->setiTank(-1);
        if(Engine[2]->getiTank() == tank) Engine[2]->setiTank(-1);
    }

   // Si la 2nd pompe en marche il est reserve au moteur qui lui est affecté
    if( pTank[tank]->GetPumpStatus((pump == 0) ? 1 : 0) == 1 ) {
        for( int i=0 ; i < 3 ; i++ ) {
            if(i!=tank)
                if(Engine[i]->getiTank() == tank) Engine[i]->setiTank(-1);
        }
    }
    str = tr("Panne Réservoir %1 Pompe %2")
        .arg(tank+1, 0, 10)
        .arg(pump+1, 0, 10);

    addLog(str);

    refreshScreen();
}

void MainWindow::SaveFlight()
{
    QDate dt = QDate::currentDate();
    QTime tt = QTime::currentTime();
    QString  nomFichier;

    int note = QInputDialog::getInt(this, tr("Evaluation"), tr("Note"), 0, 0, 10,1);
    nomFichier = tr("Note[%1]\n")
        .arg(note, 0, 10);

    ui->Enregistreur->appendPlainText(nomFichier);

    nomFichier = QFileDialog::getSaveFileName(this, tr("Sauvegarder la simulation"),
                                              QApplication::applicationDirPath() + "/pilotes/" + aviator + "_" +  dt.toString(Qt::ISODate) + "_" + tt.toString(Qt::ISODate) + ".txt",
                                              tr("Fichier Texte (*.txt)"));

    if (nomFichier != "") {

        QFile file(nomFichier);

        if (file.open(QIODevice::ReadWrite)) {

            QTextStream stream(&file);
            stream << ui->Enregistreur->toPlainText();
            file.flush();
            file.close();

        } else {
            QMessageBox::critical(this, tr("Erreur"), tr("Impossible de sauvegarder la simulation"));
            return;
        }
    }
}

void MainWindow::addLog(QString s)
{
    ui->Enregistreur->appendPlainText(s);
}

int MainWindow::getAviator()
{
    if ( aviator == "QUIT" )
        return -1;
    else
        return 0;
}

//
// Divers
//
void MainWindow::closeEvent(QCloseEvent *event)
{
    QApplication::quit();
}

// Rafraichissement cockpit
void MainWindow::refreshScreen()
{
    int s;

    // Refresh réservoirs
    ui->Tank1->setStyleSheet(( pTank[0]->GetTankStatus() == 0) ? C_NOCOLOR : C_TANK1);
    ui->Tank2->setStyleSheet(( pTank[1]->GetTankStatus() == 0) ? C_NOCOLOR : C_TANK2);
    ui->Tank3->setStyleSheet(( pTank[2]->GetTankStatus() == 0) ? C_NOCOLOR : C_TANK3);

    // Dessin pompes
    int i;
    i = pTank[0]->GetPumpStatus(0);
    if( i == 1  ) ui->T1_P11->setChecked(true);
    if( i == 0  ) ui->T1_P11->setChecked(false);
    if( i == -1 ) ui->T1_P11->setStyleSheet(C_ERROR);

    i = pTank[0]->GetPumpStatus(1);
    if( i == 1  ) ui->T1_P12->setChecked(true);
    if( i == 0  ) ui->T1_P12->setChecked(false);
    if( i == -1 ) ui->T1_P12->setStyleSheet(C_ERROR);

    i = pTank[1]->GetPumpStatus(0);
    if( i == 1  ) ui->T2_P11->setChecked(true);
    if( i == 0  ) ui->T2_P11->setChecked(false);
    if( i == -1 ) ui->T2_P11->setStyleSheet(C_ERROR);

    i = pTank[1]->GetPumpStatus(1);
    if( i == 1  ) ui->T2_P12->setChecked(true);
    if( i == 0  ) ui->T2_P12->setChecked(false);
    if( i == -1 ) ui->T2_P12->setStyleSheet(C_ERROR);

    i = pTank[2]->GetPumpStatus(0);
    if( i == 1  ) ui->T3_P11->setChecked(true);
    if( i == 0  ) ui->T3_P11->setChecked(false);
    if( i == -1 ) ui->T3_P11->setStyleSheet(C_ERROR);

    i = pTank[2]->GetPumpStatus(1);
    if( i == 1  ) ui->T3_P12->setChecked(true);
    if( i == 0  ) ui->T3_P12->setChecked(false);
    if( i == -1 ) ui->T3_P12->setStyleSheet(C_ERROR);

    // Dessin vanne
    ui->V12_2->setValue(Vn[0]->getStatus());
    ui->V13_2->setValue(Vn[1]->getStatus());
    ui->V23_2->setValue(Vn[2]->getStatus());

    // Dessin alimentation Moteur 1
    s = Engine[0]->getiTank();
    switch(s) {
        case 0:
            ui->M1->setStyleSheet(C_TANK1);
            ui->T1M1->setStyleSheet(C_TANK1);
            ui->T1M2_1->setStyleSheet(C_TANK1);
            ui->T1M3_1->setStyleSheet(C_TANK1);
            break;

        case 1:
            ui->M1->setStyleSheet(C_TANK2);
            ui->T1M1->setStyleSheet(C_TANK2);
            ui->T1M2_1->setStyleSheet(C_TANK2);
            ui->T1M3_1->setStyleSheet(C_TANK2);
            break;

        case 2:
            ui->M1->setStyleSheet(C_TANK3);
            ui->T1M1->setStyleSheet(C_TANK3);
            ui->T1M2_1->setStyleSheet(C_TANK3);
            ui->T1M3_1->setStyleSheet(C_TANK3);
            break;

        case -1:
            ui->M1->setStyleSheet(C_ERROR);
            ui->T1M1->setStyleSheet(C_NOCOLOR);
            ui->T1M2_1->setStyleSheet(C_NOCOLOR);
            ui->T1M3_1->setStyleSheet(C_NOCOLOR);
            break;
    }

    // Dessin alimentation Moteur 2
    s = Engine[1]->getiTank();
    switch(s) {
        case 0:
            ui->M2->setStyleSheet(C_TANK1);
            ui->T2M2->setStyleSheet(C_TANK1);
            ui->T1M2_2->setStyleSheet(C_TANK1);
            ui->T2M3_1->setStyleSheet(C_TANK1);
            break;

        case 1:
            ui->M2->setStyleSheet(C_TANK2);
            ui->T2M2->setStyleSheet(C_TANK2);
            ui->T1M2_2->setStyleSheet(C_TANK2);
            ui->T2M3_1->setStyleSheet(C_TANK2);
            break;

        case 2:
            ui->M2->setStyleSheet(C_TANK3);
            ui->T2M2->setStyleSheet(C_TANK3);
            ui->T1M2_2->setStyleSheet(C_TANK3);
            ui->T2M3_1->setStyleSheet(C_TANK3);
            break;

        case -1:
            ui->M2->setStyleSheet(C_ERROR);
            ui->T2M2->setStyleSheet(C_NOCOLOR);
            ui->T1M2_2->setStyleSheet(C_NOCOLOR);
            ui->T2M3_1->setStyleSheet(C_NOCOLOR);
            break;
    }

    // Dessin alimentation Moteur 3
    s = Engine[2]->getiTank();
    switch(s) {
        case 0:
            ui->M3->setStyleSheet(C_TANK1);
            ui->T3M3->setStyleSheet(C_TANK1);
            ui->T1M3_2->setStyleSheet(C_TANK1);
            ui->T2M3_2->setStyleSheet(C_TANK1);
            break;

        case 1:
            ui->M3->setStyleSheet(C_TANK2);
            ui->T3M3->setStyleSheet(C_TANK2);
            ui->T1M3_2->setStyleSheet(C_TANK2);
            ui->T2M3_2->setStyleSheet(C_TANK2);
            break;

        case 2:
            ui->M3->setStyleSheet(C_TANK3);
            ui->T3M3->setStyleSheet(C_TANK3);
            ui->T1M3_2->setStyleSheet(C_TANK3);
            ui->T2M3_2->setStyleSheet(C_TANK3);
            break;

        case -1:
            ui->M3->setStyleSheet(C_ERROR);
            ui->T3M3->setStyleSheet(C_NOCOLOR);
            ui->T1M3_2->setStyleSheet(C_NOCOLOR);
            ui->T2M3_2->setStyleSheet(C_NOCOLOR);
            break;
    }

    // Plus de moteur du tout
    if((Engine[0]->getiTank()==-1) && (Engine[1]->getiTank()==-1) && (Engine[2]->getiTank()==-1)) {
        QMessageBox msg;
        int ret;

        addLog("Les moteurs sont tous coupés");
        ret = msg.critical(this,tr("Crash"),tr("Les moteurs sont tous coupés"),QMessageBox::Ok|QMessageBox::Save);
        if( ret == QMessageBox::Save)
            SaveFlight();
        QApplication::quit();
    }
}

void MainWindow::on_Save_clicked()
{
    SaveFlight();
}
