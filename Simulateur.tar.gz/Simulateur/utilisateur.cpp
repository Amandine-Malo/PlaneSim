#include "utilisateur.h"
#include "ui_utilisateur.h"

Utilisateur::Utilisateur(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Utilisateur)
{
    ui->setupUi(this);
}

Utilisateur::~Utilisateur()
{
    delete ui;
}

void Utilisateur::setCockpit(MainWindow *p)
{
    cockpit = p;
}

void Utilisateur::on_PANNE_13_clicked()
{
    cockpit->ErrorPump(0,0);
}

void Utilisateur::on_PANNE_14_clicked()
{
    cockpit->ErrorPump(0,1);
}

void Utilisateur::on_PANNE_17_clicked()
{
    cockpit->ErrorPump(1,0);
}

void Utilisateur::on_PANNE_18_clicked()
{
        cockpit->ErrorPump(1,1);
}

void Utilisateur::on_PANNE_21_clicked()
{
    cockpit->ErrorPump(2,0);
}

void Utilisateur::on_PANNE_22_clicked()
{
    cockpit->ErrorPump(2,1);
}

void Utilisateur::on_VIDANGE_4_clicked()
{
    cockpit->Vidange(0);
}

void Utilisateur::on_VIDANGE_5_clicked()
{
    cockpit->Vidange(1);
}

void Utilisateur::on_VIDANGE_6_clicked()
{
    cockpit->Vidange(2);
}

void Utilisateur::closeEvent(QCloseEvent *event)
{
    QApplication::quit();
}
