#include "utilisateur.h"
#include "ui_utilisateur.h"
#include <time.h>

Utilisateur::Utilisateur(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Utilisateur)
{
    ui->setupUi(this);
}

Utilisateur::~Utilisateur()
{
    delete ui;
}

void Utilisateur::setCockpit(MainWindow *p)
{
    cockpit = p;
}

void Utilisateur::on_PANNE_13_clicked()
{
    cockpit->ErrorPump(0,0);
}

void Utilisateur::on_PANNE_14_clicked()
{
    cockpit->ErrorPump(0,1);
}

void Utilisateur::on_PANNE_17_clicked()
{
    cockpit->ErrorPump(1,0);
}

void Utilisateur::on_PANNE_18_clicked()
{
    cockpit->ErrorPump(1,1);
}

void Utilisateur::on_PANNE_21_clicked()
{
    cockpit->ErrorPump(2,0);
}

void Utilisateur::on_PANNE_22_clicked()
{
    cockpit->ErrorPump(2,1);
}

void Utilisateur::on_VIDANGE_4_clicked()
{
    cockpit->Vidange(0);
}

void Utilisateur::on_VIDANGE_5_clicked()
{
    cockpit->Vidange(1);
}

void Utilisateur::on_VIDANGE_6_clicked()
{
    cockpit->Vidange(2);
}

void Utilisateur::nextAlea()
{
    int nbgen;

    // on desactive la fenetre utilisateur
    this->setEnabled(false);

    // Nouvelle panne aléatoire
    srand(time(NULL));
    nbgen=rand()%10+1;    //entre 1-10

    switch(nbgen){
    case 1:
        cockpit->ErrorPump(0,0);
        break;
    case 2:
        cockpit->ErrorPump(0,1);
        break;
    case 3:
        cockpit->ErrorPump(1,0);
        break;
    case 4:
        cockpit->ErrorPump(1,1);
        break;
    case 5:
        cockpit->ErrorPump(2,0);
        break;
    case 6:
        cockpit->ErrorPump(2,1);
        break;
    case 7:
        cockpit->Vidange(0);
        break;
    case 8:
        cockpit->Vidange(1);
        break;
    case 9:
        cockpit->Vidange(2);
        break;
    }
}

void Utilisateur::closeEvent(QCloseEvent *event)
{
    QApplication::quit();
}
