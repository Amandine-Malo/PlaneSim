#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "log.h"
#include "motor.h"
#include "vanne.h"
#include "tank.h"

#include <iostream>
#include <string>

#define C_TANK1     "background-color: #FFC87D;"
#define C_TANK2     "background-color: #7DFF94;"
#define C_TANK3     "background-color: #F0FF7D;"
#define C_NOCOLOR   ""
#define C_ERROR     "background-color: red;"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void setLog(Log *l);
    void VT12(void);
    void VT23(void);
    void ManagePump(int tank, int pump);
    void ManageVannes(int vanne);
    void Vidange(int tank);
    void ErrorPump(int tank, int pump);

private slots:
    void refreshScreen(void);

private:
    Ui::MainWindow *ui;
    Log     *flog;
    Motor   *Engine[3];
    Vanne   *VT[2];
    Vanne   *Vn[3];
    Tank    *pTank[3];
    void closeEvent(QCloseEvent* event);
};
#endif // MAINWINDOW_H
