#include "vanne.h"
#include "constantes.h"

Vanne::Vanne()
{
    status = 0;
}

Vanne::~Vanne()
{

}

void Vanne::OpenVanne()
{
    status = 1;
}

void Vanne::CloseVanne()
{
    status = 0;
}

int Vanne::getStatus()
{
    return status;
}
