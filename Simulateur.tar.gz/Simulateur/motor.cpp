#include "motor.h"

Motor::Motor()
{
    iTank = -1;
}

Motor::Motor(int i)
{
    iTank = i;
}

Motor::~Motor()
{
}

int Motor::getiTank()
{
    return iTank;
}

void Motor::setiTank(int i)
{
    iTank = i;
}
