#include "tank.h"

Tank::Tank()
{
    status = 1;
    pPump[0] = new Pump();
    pPump[1] = new Pump();
    pPump[0]->StartPump();
    pPump[1]->StopPump();
}

Tank::~Tank()
{
    delete pPump[0];
    delete pPump[1];
}

void Tank::EmptyTank()
{
    status = 0;
}

void Tank::FillTank()
{
    status = 1;
}

int Tank::GetTankStatus()
{
    return(status);
}

int Tank::GetPumpStatus(int i)
{
    return pPump[i]->GetStatus();
}

void Tank::SetPumpStatus(int i, int e)
{
    switch(e) {
        case 1:
            pPump[i]->StartPump();
            break;

        case 0:
            pPump[i]->StopPump();
            break;

         case -1:
            pPump[i]->ErrorPump();
        break;
    }
}
