#ifndef MOTOR_H
#define MOTOR_H

#include "tank.h"

class Motor
{
private:
    int iTank;

public:
    Motor();
    Motor(int i);
    ~Motor();
    int getiTank();
    void setiTank(int i);
};

#endif // MOTOR_H
