#ifndef CONSTANTES_H
#define CONSTANTES_H

#endif // CONSTANTES_H

#define R_VIDE  0
#define R_PLEIN 1

#define C_TANK1 "background-color: #FFC87D;"
#define C_TANK2 "background-color: #7DFF94;"
#define C_TANK3 "background-color: #F0FF7D;"
#define C_NOCOLOR ""
#define C_ERROR "background-color: red;"

#define P_MARCHE 1
#define P_ARRET 0
#define P_PANNE -1

#define V_OUVERTE 1
#define V_FERMEE 0
