#ifndef VANNES_H
#define VANNES_H


class Vanne
{
private:
    int status;

public:
    Vanne();
    ~Vanne();
    void OpenVanne();
    void CloseVanne();
    int getStatus();
};

#endif // VANNES_H
