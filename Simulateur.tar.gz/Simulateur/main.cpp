#include "mainwindow.h"             // QT
#include "pilote.h"
#include "utilisateur.h"
#include "log.h"

#include <QApplication>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv); //QT
    MainWindow w;               //QT
    Utilisateur u;
    Pilote p;
    Log l;

    QMessageBox msg;

    w.move(250,100);
    w.show();                       //QT

    l.move(50,300);
    l.show();

    u.move(590,100);
    u.show();
    u.setCockpit(&w);               // ENvoie de l'adresse de la calsse cokcpit pour lancer les commandes

    p.move(50,100);
    p.show();
    p.setCockpit(&w);               // ENvoie de l'adresse de la calsse cokcpit pour lancer les commandes

    w.setLog(&l);

    return a.exec();
}

