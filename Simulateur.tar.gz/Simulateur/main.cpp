#include "mainwindow.h"             // QT
#include "pilote.h"
#include "utilisateur.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv); //QT
    MainWindow w;               //QT
    Utilisateur u;
    Pilote p;

    if( w.getAviator() != -1)
    {
        w.move(250,100);
        w.show();

        u.move(590,100);
        u.show();
        u.setCockpit(&w);               // ENvoie de l'adresse de la calsse cokcpit pour lancer les commandes

        p.move(50,100);
        p.show();
        p.setCockpit(&w);               // ENvoie de l'adresse de la calsse cokcpit pour lancer les commandes
        p.setUtilisateur(&u);

        return a.exec();
    }

}

