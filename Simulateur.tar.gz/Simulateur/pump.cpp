#include "pump.h"

Pump::Pump()
{
    status = 0;
}

Pump::~Pump()
{

}

void Pump::StartPump()
{
    status = 1;
}

void Pump::StopPump()
{
    status = 0;
}

void Pump::ErrorPump()
{
    status = -1;
}

int Pump::GetStatus()
{
    return status;
}
