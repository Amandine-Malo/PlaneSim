#ifndef TANK_H
#define TANK_H

#include <QMainWindow>

#include "pump.h"

class Tank
{
private:
    int     status;     // etat réservoir
    Pump    *pPump[2];  // pompes

public:
    Tank();
    ~Tank();
    void EmptyTank();
    void FillTank();
    int GetTankStatus();
    int GetPumpStatus(int i);
    void SetPumpStatus(int i, int e);
};

#endif // TANK_H
