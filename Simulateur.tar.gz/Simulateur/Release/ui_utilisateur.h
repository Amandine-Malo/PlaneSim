/********************************************************************************
** Form generated from reading UI file 'utilisateur.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UTILISATEUR_H
#define UI_UTILISATEUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Utilisateur
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox_6;
    QPushButton *VIDANGE_4;
    QPushButton *VIDANGE_5;
    QPushButton *VIDANGE_6;
    QGroupBox *groupBox_7;
    QGroupBox *groupBox_8;
    QPushButton *PANNE_13;
    QPushButton *PANNE_14;
    QGroupBox *groupBox_9;
    QPushButton *PANNE_17;
    QPushButton *PANNE_18;
    QGroupBox *groupBox_10;
    QPushButton *PANNE_21;
    QPushButton *PANNE_22;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Utilisateur)
    {
        if (Utilisateur->objectName().isEmpty())
            Utilisateur->setObjectName(QString::fromUtf8("Utilisateur"));
        Utilisateur->resize(177, 435);
        Utilisateur->setMaximumSize(QSize(16777209, 16777215));
        centralwidget = new QWidget(Utilisateur);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox_6 = new QGroupBox(centralwidget);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setGeometry(QRect(20, 260, 141, 131));
        QFont font;
        font.setPointSize(9);
        groupBox_6->setFont(font);
        VIDANGE_4 = new QPushButton(groupBox_6);
        VIDANGE_4->setObjectName(QString::fromUtf8("VIDANGE_4"));
        VIDANGE_4->setGeometry(QRect(30, 30, 83, 25));
        VIDANGE_4->setFont(font);
        VIDANGE_5 = new QPushButton(groupBox_6);
        VIDANGE_5->setObjectName(QString::fromUtf8("VIDANGE_5"));
        VIDANGE_5->setGeometry(QRect(30, 60, 83, 25));
        VIDANGE_5->setFont(font);
        VIDANGE_6 = new QPushButton(groupBox_6);
        VIDANGE_6->setObjectName(QString::fromUtf8("VIDANGE_6"));
        VIDANGE_6->setGeometry(QRect(30, 90, 83, 25));
        VIDANGE_6->setFont(font);
        groupBox_7 = new QGroupBox(centralwidget);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(30, 10, 111, 241));
        groupBox_7->setFont(font);
        groupBox_8 = new QGroupBox(groupBox_7);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setGeometry(QRect(10, 30, 91, 61));
        groupBox_8->setFont(font);
        PANNE_13 = new QPushButton(groupBox_8);
        PANNE_13->setObjectName(QString::fromUtf8("PANNE_13"));
        PANNE_13->setGeometry(QRect(10, 30, 31, 21));
        PANNE_13->setFont(font);
        PANNE_14 = new QPushButton(groupBox_8);
        PANNE_14->setObjectName(QString::fromUtf8("PANNE_14"));
        PANNE_14->setGeometry(QRect(50, 30, 31, 21));
        PANNE_14->setFont(font);
        groupBox_9 = new QGroupBox(groupBox_7);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        groupBox_9->setGeometry(QRect(10, 100, 91, 61));
        groupBox_9->setFont(font);
        PANNE_17 = new QPushButton(groupBox_9);
        PANNE_17->setObjectName(QString::fromUtf8("PANNE_17"));
        PANNE_17->setGeometry(QRect(10, 30, 31, 21));
        PANNE_17->setFont(font);
        PANNE_18 = new QPushButton(groupBox_9);
        PANNE_18->setObjectName(QString::fromUtf8("PANNE_18"));
        PANNE_18->setGeometry(QRect(50, 30, 31, 21));
        PANNE_18->setFont(font);
        groupBox_10 = new QGroupBox(groupBox_7);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        groupBox_10->setGeometry(QRect(10, 170, 91, 61));
        groupBox_10->setFont(font);
        PANNE_21 = new QPushButton(groupBox_10);
        PANNE_21->setObjectName(QString::fromUtf8("PANNE_21"));
        PANNE_21->setGeometry(QRect(10, 30, 31, 21));
        PANNE_21->setFont(font);
        PANNE_22 = new QPushButton(groupBox_10);
        PANNE_22->setObjectName(QString::fromUtf8("PANNE_22"));
        PANNE_22->setGeometry(QRect(50, 30, 31, 21));
        PANNE_22->setFont(font);
        Utilisateur->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Utilisateur);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 177, 22));
        Utilisateur->setMenuBar(menubar);
        statusbar = new QStatusBar(Utilisateur);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Utilisateur->setStatusBar(statusbar);

        retranslateUi(Utilisateur);

        QMetaObject::connectSlotsByName(Utilisateur);
    } // setupUi

    void retranslateUi(QMainWindow *Utilisateur)
    {
        Utilisateur->setWindowTitle(QCoreApplication::translate("Utilisateur", "Pannes", nullptr));
#if QT_CONFIG(statustip)
        Utilisateur->setStatusTip(QCoreApplication::translate("Utilisateur", "Pannes \303\240 injecter", nullptr));
#endif // QT_CONFIG(statustip)
        groupBox_6->setTitle(QCoreApplication::translate("Utilisateur", "Vidanges R\303\251servoirs", nullptr));
        VIDANGE_4->setText(QCoreApplication::translate("Utilisateur", "Tank 1", nullptr));
        VIDANGE_5->setText(QCoreApplication::translate("Utilisateur", "Tank 2", nullptr));
        VIDANGE_6->setText(QCoreApplication::translate("Utilisateur", "Tank 3", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("Utilisateur", "Pannes Pompes", nullptr));
        groupBox_8->setTitle(QCoreApplication::translate("Utilisateur", "Tank 1", nullptr));
        PANNE_13->setText(QCoreApplication::translate("Utilisateur", "P11", nullptr));
        PANNE_14->setText(QCoreApplication::translate("Utilisateur", "P12", nullptr));
        groupBox_9->setTitle(QCoreApplication::translate("Utilisateur", "Tank 2", nullptr));
        PANNE_17->setText(QCoreApplication::translate("Utilisateur", "P11", nullptr));
        PANNE_18->setText(QCoreApplication::translate("Utilisateur", "P12", nullptr));
        groupBox_10->setTitle(QCoreApplication::translate("Utilisateur", "Tank 3", nullptr));
        PANNE_21->setText(QCoreApplication::translate("Utilisateur", "P11", nullptr));
        PANNE_22->setText(QCoreApplication::translate("Utilisateur", "P12", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Utilisateur: public Ui_Utilisateur {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UTILISATEUR_H
