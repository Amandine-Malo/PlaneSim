/********************************************************************************
** Form generated from reading UI file 'pilote.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PILOTE_H
#define UI_PILOTE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Pilote
{
public:
    QWidget *centralwidget;
    QPushButton *V23;
    QPushButton *V12;
    QPushButton *P22;
    QPushButton *V13;
    QPushButton *P12;
    QPushButton *VT12;
    QPushButton *VT23;
    QPushButton *P32;
    QCheckBox *Pannealea;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Pilote)
    {
        if (Pilote->objectName().isEmpty())
            Pilote->setObjectName(QString::fromUtf8("Pilote"));
        Pilote->setWindowModality(Qt::NonModal);
        Pilote->resize(186, 194);
        Pilote->setContextMenuPolicy(Qt::DefaultContextMenu);
        centralwidget = new QWidget(Pilote);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        V23 = new QPushButton(centralwidget);
        V23->setObjectName(QString::fromUtf8("V23"));
        V23->setGeometry(QRect(120, 90, 41, 23));
        QFont font;
        font.setPointSize(9);
        V23->setFont(font);
        V12 = new QPushButton(centralwidget);
        V12->setObjectName(QString::fromUtf8("V12"));
        V12->setGeometry(QRect(20, 90, 41, 23));
        V12->setFont(font);
        P22 = new QPushButton(centralwidget);
        P22->setObjectName(QString::fromUtf8("P22"));
        P22->setGeometry(QRect(70, 50, 41, 23));
        P22->setFont(font);
        V13 = new QPushButton(centralwidget);
        V13->setObjectName(QString::fromUtf8("V13"));
        V13->setGeometry(QRect(70, 90, 41, 23));
        V13->setFont(font);
        P12 = new QPushButton(centralwidget);
        P12->setObjectName(QString::fromUtf8("P12"));
        P12->setGeometry(QRect(20, 50, 41, 23));
        P12->setFont(font);
        VT12 = new QPushButton(centralwidget);
        VT12->setObjectName(QString::fromUtf8("VT12"));
        VT12->setGeometry(QRect(40, 10, 41, 23));
        VT12->setFont(font);
        VT23 = new QPushButton(centralwidget);
        VT23->setObjectName(QString::fromUtf8("VT23"));
        VT23->setGeometry(QRect(100, 10, 41, 23));
        VT23->setFont(font);
        P32 = new QPushButton(centralwidget);
        P32->setObjectName(QString::fromUtf8("P32"));
        P32->setGeometry(QRect(120, 50, 41, 23));
        P32->setFont(font);
        Pannealea = new QCheckBox(centralwidget);
        Pannealea->setObjectName(QString::fromUtf8("Pannealea"));
        Pannealea->setGeometry(QRect(20, 130, 141, 23));
        Pilote->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Pilote);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 186, 22));
        Pilote->setMenuBar(menubar);
        statusbar = new QStatusBar(Pilote);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Pilote->setStatusBar(statusbar);

        retranslateUi(Pilote);

        QMetaObject::connectSlotsByName(Pilote);
    } // setupUi

    void retranslateUi(QMainWindow *Pilote)
    {
        Pilote->setWindowTitle(QCoreApplication::translate("Pilote", "Pilote", nullptr));
#if QT_CONFIG(statustip)
        Pilote->setStatusTip(QCoreApplication::translate("Pilote", "Interface Pilote", nullptr));
#endif // QT_CONFIG(statustip)
        V23->setText(QCoreApplication::translate("Pilote", "V23", nullptr));
        V12->setText(QCoreApplication::translate("Pilote", "V12", nullptr));
        P22->setText(QCoreApplication::translate("Pilote", "P22", nullptr));
        V13->setText(QCoreApplication::translate("Pilote", "V13", nullptr));
        P12->setText(QCoreApplication::translate("Pilote", "P12", nullptr));
        VT12->setText(QCoreApplication::translate("Pilote", "VT12", nullptr));
        VT23->setText(QCoreApplication::translate("Pilote", "VT23", nullptr));
        P32->setText(QCoreApplication::translate("Pilote", "P32", nullptr));
        Pannealea->setText(QCoreApplication::translate("Pilote", "Pannes Al\303\251atoires", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Pilote: public Ui_Pilote {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PILOTE_H
