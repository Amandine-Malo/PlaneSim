/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGroupBox *Tank2;
    QCheckBox *T2_P12;
    QCheckBox *T2_P11;
    QGroupBox *Tank3;
    QCheckBox *T3_P12;
    QCheckBox *T3_P11;
    QGroupBox *Tank1;
    QCheckBox *T1_P12;
    QCheckBox *T1_P11;
    QSlider *VT12_2;
    QSlider *VT23_2;
    QSlider *V23_2;
    QSlider *V13_2;
    QSlider *V12_2;
    QGroupBox *M1;
    QGroupBox *M2;
    QGroupBox *M3;
    QFrame *T1M1;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QFrame *T2M2;
    QFrame *T3M3;
    QFrame *T1M2_1;
    QFrame *T1M2_2;
    QFrame *T1M3_1;
    QFrame *T1M3_2;
    QFrame *T2M3_1;
    QFrame *T2M3_2;
    QFrame *T1T2;
    QFrame *T2T3;
    QPlainTextEdit *Enregistreur;
    QPushButton *Save;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setWindowModality(Qt::NonModal);
        MainWindow->resize(323, 515);
        MainWindow->setTabShape(QTabWidget::Rounded);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Tank2 = new QGroupBox(centralwidget);
        Tank2->setObjectName(QString::fromUtf8("Tank2"));
        Tank2->setGeometry(QRect(130, 10, 61, 131));
        QFont font;
        font.setPointSize(9);
        Tank2->setFont(font);
        Tank2->setFocusPolicy(Qt::NoFocus);
        Tank2->setStyleSheet(QString::fromUtf8("background-color: #7DFF94;"));
        T2_P12 = new QCheckBox(Tank2);
        T2_P12->setObjectName(QString::fromUtf8("T2_P12"));
        T2_P12->setEnabled(false);
        T2_P12->setGeometry(QRect(10, 100, 51, 23));
        T2_P12->setFont(font);
        T2_P11 = new QCheckBox(Tank2);
        T2_P11->setObjectName(QString::fromUtf8("T2_P11"));
        T2_P11->setEnabled(false);
        T2_P11->setGeometry(QRect(10, 80, 51, 23));
        T2_P11->setFont(font);
        T2_P11->setChecked(true);
        Tank3 = new QGroupBox(centralwidget);
        Tank3->setObjectName(QString::fromUtf8("Tank3"));
        Tank3->setGeometry(QRect(250, 10, 61, 131));
        Tank3->setFont(font);
        Tank3->setFocusPolicy(Qt::NoFocus);
        Tank3->setStyleSheet(QString::fromUtf8("background-color: #F0FF7D;"));
        T3_P12 = new QCheckBox(Tank3);
        T3_P12->setObjectName(QString::fromUtf8("T3_P12"));
        T3_P12->setEnabled(false);
        T3_P12->setGeometry(QRect(10, 100, 51, 23));
        T3_P12->setFont(font);
        T3_P11 = new QCheckBox(Tank3);
        T3_P11->setObjectName(QString::fromUtf8("T3_P11"));
        T3_P11->setEnabled(false);
        T3_P11->setGeometry(QRect(10, 80, 51, 23));
        T3_P11->setFont(font);
        T3_P11->setChecked(true);
        Tank1 = new QGroupBox(centralwidget);
        Tank1->setObjectName(QString::fromUtf8("Tank1"));
        Tank1->setGeometry(QRect(10, 10, 61, 131));
        Tank1->setFont(font);
        Tank1->setFocusPolicy(Qt::NoFocus);
        Tank1->setAutoFillBackground(false);
        Tank1->setStyleSheet(QString::fromUtf8("background-color: #FFC87D;"));
        T1_P12 = new QCheckBox(Tank1);
        T1_P12->setObjectName(QString::fromUtf8("T1_P12"));
        T1_P12->setEnabled(false);
        T1_P12->setGeometry(QRect(10, 100, 51, 23));
        T1_P12->setFont(font);
        T1_P11 = new QCheckBox(Tank1);
        T1_P11->setObjectName(QString::fromUtf8("T1_P11"));
        T1_P11->setEnabled(false);
        T1_P11->setGeometry(QRect(10, 80, 51, 23));
        T1_P11->setFont(font);
        T1_P11->setStyleSheet(QString::fromUtf8(""));
        T1_P11->setChecked(true);
        VT12_2 = new QSlider(centralwidget);
        VT12_2->setObjectName(QString::fromUtf8("VT12_2"));
        VT12_2->setEnabled(false);
        VT12_2->setGeometry(QRect(90, 60, 20, 41));
        VT12_2->setFont(font);
        VT12_2->setMaximum(1);
        VT12_2->setOrientation(Qt::Vertical);
        VT12_2->setTickPosition(QSlider::NoTicks);
        VT23_2 = new QSlider(centralwidget);
        VT23_2->setObjectName(QString::fromUtf8("VT23_2"));
        VT23_2->setEnabled(false);
        VT23_2->setGeometry(QRect(210, 60, 20, 41));
        VT23_2->setFont(font);
        VT23_2->setMaximum(1);
        VT23_2->setOrientation(Qt::Vertical);
        V23_2 = new QSlider(centralwidget);
        V23_2->setObjectName(QString::fromUtf8("V23_2"));
        V23_2->setEnabled(false);
        V23_2->setGeometry(QRect(210, 250, 20, 41));
        V23_2->setFont(font);
        V23_2->setMaximum(1);
        V23_2->setOrientation(Qt::Vertical);
        V13_2 = new QSlider(centralwidget);
        V13_2->setObjectName(QString::fromUtf8("V13_2"));
        V13_2->setEnabled(false);
        V13_2->setGeometry(QRect(210, 150, 20, 41));
        V13_2->setFont(font);
        V13_2->setMaximum(1);
        V13_2->setOrientation(Qt::Vertical);
        V12_2 = new QSlider(centralwidget);
        V12_2->setObjectName(QString::fromUtf8("V12_2"));
        V12_2->setEnabled(false);
        V12_2->setGeometry(QRect(90, 200, 20, 41));
        V12_2->setFont(font);
        V12_2->setMaximum(1);
        V12_2->setOrientation(Qt::Vertical);
        M1 = new QGroupBox(centralwidget);
        M1->setObjectName(QString::fromUtf8("M1"));
        M1->setGeometry(QRect(10, 320, 61, 71));
        M1->setFont(font);
        M1->setFocusPolicy(Qt::NoFocus);
        M1->setAutoFillBackground(false);
        M2 = new QGroupBox(centralwidget);
        M2->setObjectName(QString::fromUtf8("M2"));
        M2->setGeometry(QRect(130, 320, 61, 71));
        M2->setFont(font);
        M2->setFocusPolicy(Qt::NoFocus);
        M2->setAutoFillBackground(false);
        M3 = new QGroupBox(centralwidget);
        M3->setObjectName(QString::fromUtf8("M3"));
        M3->setGeometry(QRect(250, 320, 61, 71));
        M3->setFont(font);
        M3->setFocusPolicy(Qt::NoFocus);
        M3->setAutoFillBackground(false);
        T1M1 = new QFrame(centralwidget);
        T1M1->setObjectName(QString::fromUtf8("T1M1"));
        T1M1->setEnabled(false);
        T1M1->setGeometry(QRect(30, 140, 20, 201));
        T1M1->setFont(font);
        T1M1->setStyleSheet(QString::fromUtf8("background-color: #FFC87D;"));
        T1M1->setFrameShape(QFrame::VLine);
        T1M1->setFrameShadow(QFrame::Sunken);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 40, 41, 17));
        label->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(200, 40, 41, 17));
        label_2->setFont(font);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(90, 240, 31, 17));
        label_3->setFont(font);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(210, 190, 31, 17));
        label_4->setFont(font);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(210, 290, 31, 17));
        label_5->setFont(font);
        T2M2 = new QFrame(centralwidget);
        T2M2->setObjectName(QString::fromUtf8("T2M2"));
        T2M2->setEnabled(false);
        T2M2->setGeometry(QRect(150, 140, 20, 201));
        T2M2->setFont(font);
        T2M2->setStyleSheet(QString::fromUtf8("background-color: #7DFF94;"));
        T2M2->setFrameShape(QFrame::VLine);
        T2M2->setFrameShadow(QFrame::Sunken);
        T3M3 = new QFrame(centralwidget);
        T3M3->setObjectName(QString::fromUtf8("T3M3"));
        T3M3->setEnabled(false);
        T3M3->setGeometry(QRect(270, 140, 20, 201));
        T3M3->setFont(font);
        T3M3->setStyleSheet(QString::fromUtf8("background-color: #F0FF7D;"));
        T3M3->setFrameShape(QFrame::VLine);
        T3M3->setFrameShadow(QFrame::Sunken);
        T1M2_1 = new QFrame(centralwidget);
        T1M2_1->setObjectName(QString::fromUtf8("T1M2_1"));
        T1M2_1->setGeometry(QRect(50, 220, 41, 16));
        T1M2_1->setFont(font);
        T1M2_1->setStyleSheet(QString::fromUtf8("background-color: #FFC87D;"));
        T1M2_1->setFrameShape(QFrame::HLine);
        T1M2_1->setFrameShadow(QFrame::Sunken);
        T1M2_2 = new QFrame(centralwidget);
        T1M2_2->setObjectName(QString::fromUtf8("T1M2_2"));
        T1M2_2->setGeometry(QRect(110, 220, 41, 20));
        T1M2_2->setFont(font);
        T1M2_2->setStyleSheet(QString::fromUtf8("background-color: #7DFF94;"));
        T1M2_2->setFrameShape(QFrame::HLine);
        T1M2_2->setFrameShadow(QFrame::Sunken);
        T1M3_1 = new QFrame(centralwidget);
        T1M3_1->setObjectName(QString::fromUtf8("T1M3_1"));
        T1M3_1->setGeometry(QRect(50, 160, 161, 16));
        T1M3_1->setFont(font);
        T1M3_1->setStyleSheet(QString::fromUtf8("background-color: #FFC87D;"));
        T1M3_1->setFrameShape(QFrame::HLine);
        T1M3_1->setFrameShadow(QFrame::Sunken);
        T1M3_2 = new QFrame(centralwidget);
        T1M3_2->setObjectName(QString::fromUtf8("T1M3_2"));
        T1M3_2->setGeometry(QRect(230, 160, 41, 16));
        T1M3_2->setFont(font);
        T1M3_2->setStyleSheet(QString::fromUtf8("background-color: #F0FF7D;"));
        T1M3_2->setFrameShape(QFrame::HLine);
        T1M3_2->setFrameShadow(QFrame::Sunken);
        T2M3_1 = new QFrame(centralwidget);
        T2M3_1->setObjectName(QString::fromUtf8("T2M3_1"));
        T2M3_1->setGeometry(QRect(170, 260, 41, 16));
        T2M3_1->setFont(font);
        T2M3_1->setStyleSheet(QString::fromUtf8("background-color: #7DFF94;"));
        T2M3_1->setFrameShape(QFrame::HLine);
        T2M3_1->setFrameShadow(QFrame::Sunken);
        T2M3_2 = new QFrame(centralwidget);
        T2M3_2->setObjectName(QString::fromUtf8("T2M3_2"));
        T2M3_2->setGeometry(QRect(230, 260, 41, 16));
        T2M3_2->setFont(font);
        T2M3_2->setStyleSheet(QString::fromUtf8("background-color: #F0FF7D;"));
        T2M3_2->setFrameShape(QFrame::HLine);
        T2M3_2->setFrameShadow(QFrame::Sunken);
        T1T2 = new QFrame(centralwidget);
        T1T2->setObjectName(QString::fromUtf8("T1T2"));
        T1T2->setGeometry(QRect(70, 110, 61, 16));
        QFont font1;
        font1.setPointSize(9);
        font1.setBold(false);
        font1.setWeight(50);
        T1T2->setFont(font1);
        T1T2->setFrameShape(QFrame::HLine);
        T1T2->setFrameShadow(QFrame::Sunken);
        T2T3 = new QFrame(centralwidget);
        T2T3->setObjectName(QString::fromUtf8("T2T3"));
        T2T3->setGeometry(QRect(190, 110, 61, 16));
        T2T3->setFont(font);
        T2T3->setFrameShape(QFrame::HLine);
        T2T3->setFrameShadow(QFrame::Sunken);
        Enregistreur = new QPlainTextEdit(centralwidget);
        Enregistreur->setObjectName(QString::fromUtf8("Enregistreur"));
        Enregistreur->setEnabled(true);
        Enregistreur->setGeometry(QRect(10, 400, 191, 71));
        QFont font2;
        font2.setFamily(QString::fromUtf8("DejaVu Sans"));
        font2.setPointSize(7);
        font2.setBold(false);
        font2.setWeight(50);
        Enregistreur->setFont(font2);
        Enregistreur->setLineWrapMode(QPlainTextEdit::NoWrap);
        Enregistreur->setReadOnly(true);
        Save = new QPushButton(centralwidget);
        Save->setObjectName(QString::fromUtf8("Save"));
        Save->setGeometry(QRect(220, 420, 83, 25));
        MainWindow->setCentralWidget(centralwidget);
        Tank2->raise();
        Tank3->raise();
        Tank1->raise();
        VT12_2->raise();
        VT23_2->raise();
        V23_2->raise();
        V13_2->raise();
        V12_2->raise();
        M1->raise();
        M2->raise();
        M3->raise();
        T1M1->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        T1M2_1->raise();
        T1M2_2->raise();
        T1M3_1->raise();
        T1M3_2->raise();
        T2M3_1->raise();
        T2M3_2->raise();
        T1T2->raise();
        T2T3->raise();
        T2M2->raise();
        T3M3->raise();
        Enregistreur->raise();
        Save->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 323, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Gestion Moteur", nullptr));
#if QT_CONFIG(statustip)
        MainWindow->setStatusTip(QCoreApplication::translate("MainWindow", "Gestion Moteurs", nullptr));
#endif // QT_CONFIG(statustip)
        Tank2->setTitle(QCoreApplication::translate("MainWindow", "Tank 2", nullptr));
        T2_P12->setText(QCoreApplication::translate("MainWindow", "P12", nullptr));
        T2_P11->setText(QCoreApplication::translate("MainWindow", "P11", nullptr));
        Tank3->setTitle(QCoreApplication::translate("MainWindow", "Tank 3", nullptr));
        T3_P12->setText(QCoreApplication::translate("MainWindow", "P12", nullptr));
        T3_P11->setText(QCoreApplication::translate("MainWindow", "P11", nullptr));
        Tank1->setTitle(QCoreApplication::translate("MainWindow", "Tank 1", nullptr));
        T1_P12->setText(QCoreApplication::translate("MainWindow", "P12", nullptr));
        T1_P11->setText(QCoreApplication::translate("MainWindow", "P11", nullptr));
        M1->setTitle(QCoreApplication::translate("MainWindow", "M1", nullptr));
        M2->setTitle(QCoreApplication::translate("MainWindow", "M2", nullptr));
        M3->setTitle(QCoreApplication::translate("MainWindow", "M3", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "VT12", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "VT23", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "V12", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "V13", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "V23", nullptr));
        Enregistreur->setDocumentTitle(QString());
        Enregistreur->setPlainText(QString());
        Save->setText(QCoreApplication::translate("MainWindow", "Enregistrer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
